# SnapLock — projet Android de démonstration

Ce projet est le **code source d'une application séparée**, pas un APK déjà compilé.

## Ce que fait cette première version
- Écran de paramètres avec un interrupteur ON/OFF.
- Utilise le dialogue biométrique officiel d'Android (empreinte et, en secours, le verrouillage de l'appareil).
- Service Accessibilité pour détecter le passage de Snapchat au premier plan.

## Limites importantes
- Il n'ajoute **pas** un bouton dans les paramètres de Snapchat. Snapchat est une application propriétaire; cette fonction ne peut pas être injectée proprement depuis une application tierce.
- La détection via Accessibilité peut varier selon la version Android/Samsung et peut présenter des contournements. Ce prototype n'est pas une garantie de sécurité absolue.
- Le service Accessibilité est une autorisation sensible. N'active que des services dont tu as examiné le code et compris le fonctionnement.
- Pour un usage réel, il faut tester sur l'appareil cible, améliorer le cycle de verrouillage, gérer la reprise après interruption et signer l'application.

## Compiler
1. Installe Android Studio.
2. Ouvre le dossier `SnapLockAndroid`.
3. Laisse Gradle synchroniser le projet.
4. Compile avec **Build > Build APK(s)**.
5. Teste sur ton téléphone. Il faudra activer le service SnapLock dans **Paramètres Android > Accessibilité**.

Package Snapchat détecté : `com.snapchat.android`.
