package com.example.snaplock

import android.app.Activity
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat

class LockActivity : Activity() {
    private var promptShown = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawableResource(android.R.color.black)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundColor(Color.rgb(18, 18, 24))
        }
        val title = TextView(this).apply {
            text = "Snapchat verrouillé"
            textSize = 26f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val message = TextView(this).apply {
            text = "Authentifie-toi avec l'empreinte digitale pour continuer."
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 0)
        }
        layout.addView(title)
        layout.addView(message)
        setContentView(layout)
        authenticate()
    }

    private fun authenticate() {
        if (promptShown) return
        promptShown = true
        val manager = BiometricManager.from(this)
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or
            BiometricManager.Authenticators.DEVICE_CREDENTIAL
        if (manager.canAuthenticate(authenticators) != BiometricManager.BIOMETRIC_SUCCESS) {
            finish()
            return
        }
        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                getSharedPreferences("snaplock", MODE_PRIVATE)
                    .edit().putBoolean("unlocked_session", true).apply()
                setResult(RESULT_OK)
                finish()
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                promptShown = false
                if (errorCode != BiometricPrompt.ERROR_USER_CANCELED &&
                    errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON) {
                    finish()
                }
            }
            override fun onAuthenticationFailed() {
                promptShown = false
            }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Déverrouiller Snapchat")
            .setSubtitle("Utilise ton empreinte ou le verrouillage de l'appareil")
            .setAllowedAuthenticators(authenticators)
            .build()
        prompt.authenticate(info)
    }

    override fun onResume() {
        super.onResume()
        if (!promptShown) authenticate()
    }
}
