package com.example.snaplock

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class AppWatcherService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        // Ignore our own lock screen so its appearance does not reset the session.
        if (pkg == packageName) return

        val prefs = getSharedPreferences("snaplock", MODE_PRIVATE)
        if (pkg == "com.snapchat.android") {
            val enabled = prefs.getBoolean("enabled", false)
            val unlocked = prefs.getBoolean("unlocked_session", false)
            if (enabled && !unlocked) {
                prefs.edit().putBoolean("unlocked_session", true).apply()
                val intent = Intent(this, LockActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                startActivity(intent)
            }
        } else {
            // Leaving Snapchat ends the unlocked session.
            prefs.edit().putBoolean("unlocked_session", false).apply()
        }
    }

    override fun onInterrupt() {}
}
